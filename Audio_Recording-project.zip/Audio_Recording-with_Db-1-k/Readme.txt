Run this project directly...record the audio and store it to the database..

after recording the audio,please run the page Ret.aspx to hear the audio which is
stored in database...

Note:I'm still working on this project to add user login and necessary things.